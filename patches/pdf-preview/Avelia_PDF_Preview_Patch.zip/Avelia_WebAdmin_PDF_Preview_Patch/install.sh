#!/usr/bin/env bash
set -Eeuo pipefail
BASE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
WEB=/opt/avelia-web-terminal/public
[[ $EUID -eq 0 ]] || { echo 'sudo で実行してください。' >&2; exit 1; }
for cmd in php cp mktemp; do command -v "$cmd" >/dev/null 2>&1 || { echo "Missing command: $cmd" >&2; exit 1; }; done
if ! command -v patch >/dev/null 2>&1; then dnf install -y patch; fi
command -v patch >/dev/null 2>&1 || { echo 'GNU patch is unavailable' >&2; exit 1; }
for f in files_api.php files.js files.php; do [[ -f "$WEB/$f" ]] || { echo "Missing: $WEB/$f" >&2; exit 1; }; done
if grep -Fq "if(\$action==='pdf_preview')" "$WEB/files_api.php"; then
 echo 'PDFプレビューパッチは適用済みです。再適用しません。' >&2; exit 1
fi
if grep -Fq "require_once __DIR__.'/folder_protection.php';" "$WEB/files_api.php"; then
 MODE=protected
 [[ -f "$WEB/folder_protection.php" ]] || { echo 'Missing folder_protection.php' >&2; exit 1; }
else MODE=plain; fi
if grep -Fq "if(\$action==='preview')" "$WEB/files_api.php"; then MODE="image_$MODE"; fi
echo "構成: $MODE"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
for f in files_api.php files.js files.php; do cp -a "$WEB/$f" "$TMP/$f"; done
for f in files_api.php files.js files.php; do
 (cd "$TMP" && patch --batch --forward --dry-run -p0 < "$BASE/$MODE/$f.patch")
 (cd "$TMP" && patch --batch --forward -p0 < "$BASE/$MODE/$f.patch")
done
php -l "$TMP/files_api.php"
php -l "$TMP/files.php"
BACKUP="/var/backups/avelia-pdf-preview-$(date +%Y%m%d-%H%M%S)-$$"
mkdir -m 0700 -p "$BACKUP"
for f in files_api.php files.js files.php; do cp -a "$WEB/$f" "$BACKUP/$f"; done
rollback(){ for f in files_api.php files.js files.php; do cp -a "$BACKUP/$f" "$WEB/$f"; done; echo "Rollback: $BACKUP" >&2; }
trap rollback ERR
for f in files_api.php files.js files.php; do cp -a "$TMP/$f" "$WEB/$f"; done
php -l "$WEB/files_api.php"
php -l "$WEB/files.php"
trap - ERR
echo "PDFプレビューの適用が完了しました。バックアップ: $BACKUP"
echo 'ブラウザでファイル管理画面を再読み込みしてください。'
