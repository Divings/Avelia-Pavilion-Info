# Avelia WebAdmin PDF Preview Patch

WebAdminのファイル管理にPDFプレビューを追加するパッチです。アヴェリア本体のソースやNginx設定は変更しません。

## 導入

```bash
unzip Avelia_WebAdmin_PDF_Preview_Patch.zip
cd Avelia_WebAdmin_PDF_Preview_Patch
sudo bash install.sh
```

`/opt/avelia-web-terminal/public`にインストール済みのWebAdminが必要です。GNU patchが未導入の場合だけdnfでインストールします。

- PDFファイルに「PDF表示」ボタンを追加し、ブラウザの組み込みPDFビューアで表示します。
- 20 MiB以下の `%PDF-` ヘッダーを持つファイルのみプレビュー可能です。
- WebAdminログインを要求します。ディレクトリ保護パッチがある場合はその認証も適用します。
- 画像プレビューパッチの有無、ディレクトリ保護パッチの有無に合わせて4種の差分を選択します。
- サーバー側ではPDFを解析・変換しません。表示・ページ操作・印刷の可否はブラウザのPDFビューアに依存します。
- パッチの適用前にdry-runとPHP構文チェックを行い、適用直前にバックアップします。
- 既存WebAdminファイルが配布時と異なる場合はdry-runで停止します。既存のアヴェリア本体やSSH/OSからのファイルアクセスは制限しません。
- ファイルパス検査は既存WebAdminに依存し、シンボリックリンクの競合など既存の制限が残ります。
- **Oracle Linux 9/10実機での動作は未検証です。** 適用前にVMスナップショットを取得してください。
