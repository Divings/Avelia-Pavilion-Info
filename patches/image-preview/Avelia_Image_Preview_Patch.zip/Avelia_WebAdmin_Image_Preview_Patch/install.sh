#!/usr/bin/env bash
set -Eeuo pipefail
BASE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
WEB=/opt/avelia-web-terminal/public
[[ $EUID -eq 0 ]] || { echo 'sudo で実行してください。' >&2; exit 1; }
for cmd in patch php cp mktemp; do
 if ! command -v "$cmd" >/dev/null 2>&1; then
  if [[ "$cmd" == patch ]]; then dnf install -y patch; else echo "Missing command: $cmd" >&2; exit 1; fi
 fi
done
for f in files_api.php files.js files.php; do
 [[ -f "$WEB/$f" ]] || { echo "Missing: $WEB/$f" >&2; exit 1; }
done
if grep -Fq "if(\$action==='preview')" "$WEB/files_api.php"; then
 echo '画像プレビューパッチが適用済みの可能性があります。再適用せず停止します。' >&2
 exit 1
fi
if grep -Fq "require_once __DIR__.'/folder_protection.php';" "$WEB/files_api.php"; then
 MODE=protected
 [[ -f "$WEB/folder_protection.php" ]] || { echo '保護用PHPファイルがありません。' >&2; exit 1; }
else
 MODE=plain
fi
echo "検出した構成: $MODE"
TMP="$(mktemp -d)"
cleanup(){ rm -rf "$TMP"; }
trap cleanup EXIT
for f in files_api.php files.js files.php; do
 cp -a "$WEB/$f" "$TMP/$f"
 (cd "$TMP" && patch --batch --forward --dry-run -p0 < "$BASE/$MODE/$f.patch")
 (cd "$TMP" && patch --batch --forward -p0 < "$BASE/$MODE/$f.patch")
done
php -l "$TMP/files_api.php"
php -l "$TMP/files.php"
BACKUP="/var/backups/avelia-image-preview-$(date +%Y%m%d-%H%M%S)-$$"
mkdir -m 0700 -p "$BACKUP"
for f in files_api.php files.js files.php; do cp -a "$WEB/$f" "$BACKUP/$f"; done
rollback(){
 for f in files_api.php files.js files.php; do cp -a "$BACKUP/$f" "$WEB/$f"; done
 echo "適用中にエラーが発生したためバックアップから復元しました: $BACKUP" >&2
}
trap rollback ERR
for f in files_api.php files.js files.php; do cp -a "$TMP/$f" "$WEB/$f"; done
php -l "$WEB/files_api.php"
php -l "$WEB/files.php"
trap - ERR
echo "適用完了。バックアップ: $BACKUP"
echo 'ブラウザでファイル管理画面を再読み込みしてください。'
