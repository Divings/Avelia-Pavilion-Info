#!/usr/bin/env bash
set -Eeuo pipefail
BASE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
WEB=/opt/avelia-web-terminal/public
[[ $EUID -eq 0 ]] || { echo 'sudo で実行してください' >&2; exit 1; }
for cmd in patch php dnf; do
 if ! command -v "$cmd" >/dev/null 2>&1; then
   if [[ "$cmd" == patch ]]; then dnf install -y patch; else echo "Missing: $cmd" >&2; exit 1; fi
 fi
done
for f in files.php files.js files_api.php; do
 [[ -f "$WEB/$f" ]] || { echo "Missing: $WEB/$f" >&2; exit 1; }
 (cd "$WEB" && patch --batch --forward --dry-run -p0 < "$BASE/$f.patch")
done
[[ ! -e "$WEB/folder_protection.php" ]] || { echo 'folder_protection.php already exists; aborting' >&2; exit 1; }
[[ ! -e /var/lib/avelia-pavilion-protection/folders.json ]] || { echo 'Protection database exists; aborting to avoid overwriting' >&2; exit 1; }
# Validate patched PHP using temporary copies, not nonexistent files in the ZIP.
TMPDIR_PATCH="$(mktemp -d)"
cleanup_tmp(){ rm -rf "$TMPDIR_PATCH"; }
trap cleanup_tmp EXIT
for f in files.php files.js files_api.php; do
  cp -a "$WEB/$f" "$TMPDIR_PATCH/$f"
  (cd "$TMPDIR_PATCH" && patch --batch --forward -p0 < "$BASE/$f.patch")
done
php -l "$TMPDIR_PATCH/files_api.php" >/dev/null
php -l "$TMPDIR_PATCH/files.php" >/dev/null
php -l "$BASE/folder_protection.php" >/dev/null
# Back up all files before modifications.
BACKUP="/var/backups/avelia-folder-password-$(date +%Y%m%d-%H%M%S)-$$"
mkdir -m 0700 -p "$BACKUP"
for f in files.php files.js files_api.php; do cp -a "$WEB/$f" "$BACKUP/$f"; done
rollback(){
  for f in files.php files.js files_api.php; do cp -a "$BACKUP/$f" "$WEB/$f"; done
  rm -f "$WEB/folder_protection.php"
  echo "Rolled back web files; backup: $BACKUP" >&2
}
trap rollback ERR
install -d -o nginx -g nginx -m 0700 /var/lib/avelia-pavilion-protection
install -o nginx -g nginx -m 0600 /dev/null /var/lib/avelia-pavilion-protection/folders.json
printf '{}\n' > /var/lib/avelia-pavilion-protection/folders.json
for f in files.php files.js files_api.php; do
  (cd "$WEB" && patch --batch --forward -p0 < "$BASE/$f.patch")
done
install -o root -g root -m 0644 "$BASE/folder_protection.php" "$WEB/folder_protection.php"
for f in files.php files_api.php folder_protection.php; do php -l "$WEB/$f"; done
if command -v restorecon >/dev/null 2>&1; then
  restorecon -v "$WEB/folder_protection.php" || true
  restorecon -Rv /var/lib/avelia-pavilion-protection || true
fi
# SELinux persistent label for PHP-FPM writable metadata; semanage may need policycoreutils-python-utils.
if command -v getenforce >/dev/null 2>&1 && [[ "$(getenforce)" != Disabled ]]; then
  command -v semanage >/dev/null 2>&1 || dnf install -y policycoreutils-python-utils
  semanage fcontext -a -t httpd_sys_rw_content_t '/var/lib/avelia-pavilion-protection(/.*)?'
  restorecon -Rv /var/lib/avelia-pavilion-protection
fi
trap - ERR
echo "Patch applied. Backups: $BACKUP"
