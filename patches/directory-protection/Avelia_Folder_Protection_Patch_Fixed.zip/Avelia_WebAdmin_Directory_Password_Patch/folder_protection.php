<?php
declare(strict_types=1);
// Store protection rules outside the web root and shared storage.
const AVELIA_PROTECT_DB = '/var/lib/avelia-pavilion-protection/folders.json';
function protect_db(): array {
    $raw = @file_get_contents(AVELIA_PROTECT_DB);
    if ($raw === false) throw new RuntimeException('Protection database unavailable');
    $data = json_decode($raw, true, 32, JSON_THROW_ON_ERROR);
    if (!is_array($data)) throw new RuntimeException('Invalid protection database');
    return $data;
}
function protect_change(callable $fn): void {
    $f = fopen(AVELIA_PROTECT_DB, 'c+');
    if (!$f) throw new RuntimeException('Cannot open protection database');
    try {
        if (!flock($f, LOCK_EX)) throw new RuntimeException('Cannot lock protection database');
        rewind($f); $raw = stream_get_contents($f);
        $db = $raw === '' ? [] : json_decode($raw, true, 32, JSON_THROW_ON_ERROR);
        if (!is_array($db)) throw new RuntimeException('Invalid protection database');
        $fn($db);
        $encoded = json_encode($db, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE);
        rewind($f); if (!ftruncate($f, 0) || fwrite($f, $encoded) !== strlen($encoded)) throw new RuntimeException('Cannot save protection database');
        fflush($f);
    } finally { flock($f, LOCK_UN); fclose($f); }
}
function protect_prefixes(string $relative): array {
    $parts = parts($relative); $prefixes=[]; $acc='';
    foreach ($parts as $part) { $acc=$acc===''?$part:$acc.'/'.$part; $prefixes[]=$acc; }
    return $prefixes;
}
function protect_access(string $relative): void {
    $db = protect_db();
    foreach (protect_prefixes($relative) as $p) {
        if (isset($db[$p]) && empty($_SESSION['folder_unlocks'][$p])) fail_json('Folder locked: '.$p, 423);
    }
}
function protect_no_rule_below(string $relative): void {
    foreach (protect_db() as $p=>$hash) {
        if ($p===$relative || str_starts_with($p, $relative.'/')) fail_json('Remove directory protection before renaming/deleting it',409);
    }
}
function protect_action(string $action): never {
    require_post();
    $relative=(string)($_POST['path']??'');
    $dir=checked_path($relative);
    if ($relative==='' || !is_dir($dir)) fail_json('Directory not found',404);
    $password=(string)($_POST['password']??'');
    if ($password==='' || strlen($password)>1024) fail_json('Invalid password',400);
    $db=protect_db();
    if ($action==='folder_lock') {
        protect_access($relative);
        if (isset($db[$relative])) fail_json('Directory already protected',409);
        $hash=password_hash($password,PASSWORD_DEFAULT);
        protect_change(function (&$rules) use ($relative,$hash) {
            if (isset($rules[$relative])) fail_json('Directory already protected',409);
            $rules[$relative]=$hash;
        });
        unset($_SESSION['folder_unlocks'][$relative]);
    } elseif ($action==='folder_unlock') {
        foreach (protect_prefixes($relative) as $p) {
            if (isset($db[$p]) && empty($_SESSION['folder_unlocks'][$p]) && $p!==$relative) fail_json('Unlock parent folder first',423);
        }
        if (!isset($db[$relative]) || !password_verify($password,$db[$relative])) fail_json('Incorrect password',403);
        $_SESSION['folder_unlocks'][$relative]=true;
    } elseif ($action==='folder_unprotect') {
        protect_access($relative);
        if (!isset($db[$relative]) || !password_verify($password,$db[$relative])) fail_json('Incorrect password',403);
        protect_change(function (&$rules) use ($relative,$password) {
            if (!isset($rules[$relative]) || !password_verify($password,$rules[$relative])) fail_json('Incorrect password',403);
            unset($rules[$relative]);
        });
        unset($_SESSION['folder_unlocks'][$relative]);
    }
    echo json_encode(['ok'=>true],JSON_UNESCAPED_UNICODE);exit;
}
