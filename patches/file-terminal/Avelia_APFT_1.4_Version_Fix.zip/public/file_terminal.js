(()=>{'use strict';
const el=id=>document.getElementById(id), output=el('output'), line=el('line'), csrf=JSON.parse(el('csrf').textContent);
let cwd='';const history=[];let historyIndex=0;
function print(s=''){output.textContent+=s+'\n';output.scrollTop=output.scrollHeight;}
function prompt(){el('prompt').textContent='/'+cwd+' >';}
function path(s){if(!s||s==='.')return cwd;const p=s.startsWith('/')?[]:(cwd?cwd.split('/'):[]);for(const c of s.split('/')){if(!c||c==='.')continue;if(c==='..'){p.pop();continue;}p.push(c);}return p.join('/');}
async function api(action,params={},method='POST'){
let url='files_api.php',opts={credentials:'same-origin',cache:'no-store'};
if(method==='GET'){url+='?'+new URLSearchParams({action,...params});}
else{const fd=new FormData();fd.set('action',action);fd.set('csrf',csrf);for(const [k,v] of Object.entries(params))fd.set(k,v);opts.method='POST';opts.body=fd;}
const r=await fetch(url,opts);let j;try{j=await r.json();}catch{throw Error('API response error ('+r.status+')');}if(!r.ok||!j.ok)throw Error(j.error||'Request failed');return j;
}
function tokens(s){const m=s.match(/(?:"[^"]*"|'[^']*'|\S+)/g)||[];return m.map(x=>((x[0]==='"'&&x.at(-1)==='"')||(x[0]==="'"&&x.at(-1)==="'"))?x.slice(1,-1):x);}
async function run(raw){const [cmd,...args]=tokens(raw.trim());if(!cmd)return;print('/'+cwd+' > '+raw);const target=path(args[0]);switch(cmd){
case 'help':print('help, pwd, ls [path], cd [path], cat <file>, mkdir <dir>, touch <file>, mv <src> <dest>, rm <path>, info <path>, download <file>, unlock <dir>, lock <dir>, unprotect <dir>, clear');break;
case 'unlock':case 'lock':case 'unprotect':{
if(!args[0])throw Error('Usage: '+cmd+' <directory>');
const password=window.prompt('フォルダ /'+target+' のパスワード');
if(password===null){print('Cancelled');break;}
if(!password)throw Error('Password required');
const action={unlock:'folder_unlock',lock:'folder_lock',unprotect:'folder_unprotect'}[cmd];
await api(action,{path:target,password});
print(({unlock:'Unlocked for this session',lock:'Protection enabled',unprotect:'Protection removed'})[cmd]+' /'+target);break;}
case 'pwd':print('/'+cwd);break;
case 'clear':output.textContent='';break;
case 'ls':{const j=await api('list',{path:target},'GET');for(const f of j.files)print((f.type==='dir'?'[DIR]  ':'[FILE] ')+f.name+(f.type==='file'?'  '+f.size+' B':''));if(!j.files.length)print('(empty)');break;}
case 'cd':{await api('list',{path:target},'GET');cwd=target;prompt();break;}
case 'cat':{if(!args[0])throw Error('Usage: cat <file>');const j=await api('read',{path:target});print(j.content);break;}
case 'mkdir':{if(!args[0])throw Error('Usage: mkdir <dir>');await api('mkdir',{path:target});print('Created /'+target);break;}
case 'touch':{if(!args[0])throw Error('Usage: touch <file>');await api('save',{path:target,content:''});print('Created /'+target);break;}
case 'mv':{if(!args[0]||!args[1])throw Error('Usage: mv <src> <dest>');await api('rename',{path:target,dest:path(args[1])});print('Moved');break;}
case 'rm':{if(!args[0])throw Error('Usage: rm <path>');if(!confirm('削除しますか？ /'+target+'\nフォルダは空の場合のみ削除できます。')){print('Cancelled');break;}await api('delete',{path:target});print('Deleted /'+target);break;}
case 'info':{if(!args[0])throw Error('Usage: info <path>');const seg=target.split('/'),name=seg.pop();const j=await api('list',{path:seg.join('/')},'GET');const f=j.files.find(x=>x.name===name);if(!f)throw Error('Not found');print(JSON.stringify(f,null,2));break;}
case 'download':{if(!args[0])throw Error('Usage: download <file>');const a=document.createElement('a');a.href='files_api.php?'+new URLSearchParams({action:'download',path:target});a.download='';document.body.append(a);a.click();a.remove();print('Download requested');break;}
default:throw Error('Unknown command: '+cmd);
}}
el('command').addEventListener('submit',async e=>{e.preventDefault();const raw=line.value;line.value='';if(!raw.trim())return;history.push(raw);historyIndex=history.length;try{await run(raw);}catch(err){print('ERROR: '+err.message);}line.focus();});
line.addEventListener('keydown',e=>{if(e.key==='ArrowUp'&&historyIndex>0){e.preventDefault();line.value=history[--historyIndex];}else if(e.key==='ArrowDown'){e.preventDefault();historyIndex=Math.min(history.length,historyIndex+1);line.value=history[historyIndex]||'';}});
print('Avelia Pavilion File Terminal 1.4');print('Storage root: /var/lib/avelia/shared');print('Type help for commands.');prompt();
})();
