Avelia Pavilion File Terminal 1.4 - deployment fixes

Fixes:
1. Default web root: /opt/avelia-web-terminal/public
2. Adds exact Nginx PHP location for /file_terminal.php to /etc/nginx/conf.d/avelia-terminal.conf using the same PHP-FPM upstream as /files.php; nginx -t and reload, rollback on failure.
3. Adds unlock <directory>, lock <directory>, unprotect <directory> commands, using existing password-protection API with CSRF and session handling.
4. Keeps the files.php terminal link pointed to /file_terminal.php, preserves original terminal at /.

Install: sudo bash install-apft.sh
Override root: sudo bash install-apft.sh /custom/web/public
Backups are stored in /var/tmp/apft-backup.* (contains previous files and nginx config).

Important: 'unlock' unlocks a protected folder for the current login session; 'unprotect' removes its password protection permanently. Parent directories must be unlocked first. Password is not added to command history.

Before production deployment, take a VM snapshot. Nginx configuration must match the original Pavilion setup layout. This package has not been tested on a live OL9/OL10 server.

APFT 1.3: ロールバック時にnginx -tで復元設定を検証し、systemctl reload nginxを実行。画面のバージョンをv1.3に更新。
