#!/usr/bin/env bash
set -euo pipefail
DEST="${1:-/opt/avelia-web-terminal/public}"
NGINX_CONF="/etc/nginx/conf.d/avelia-terminal.conf"
HERE="$(cd "$(dirname "$0")" && pwd)"
[[ $EUID -eq 0 ]] || { echo 'Run as root (sudo)' >&2; exit 1; }
for f in auth.php files_api.php files.php; do [[ -f "$DEST/$f" ]] || { echo "Missing $DEST/$f" >&2; exit 1; }; done
[[ -f "$NGINX_CONF" ]] || { echo "Missing $NGINX_CONF" >&2; exit 1; }
command -v nginx >/dev/null; command -v python3 >/dev/null
BACKUP="$(mktemp -d /var/tmp/apft-backup.XXXXXXXX)"
for f in files.php file_terminal.php file_terminal.js file_terminal.css; do if [[ -e "$DEST/$f" ]]; then cp -a "$DEST/$f" "$BACKUP/$f"; else touch "$BACKUP/$f.absent"; fi; done
cp -a "$NGINX_CONF" "$BACKUP/nginx.conf"
rollback(){
  local original_status=$?
  trap - ERR
  set +e
  for f in files.php file_terminal.php file_terminal.js file_terminal.css; do
    if [[ -e "$BACKUP/$f.absent" ]]; then rm -f "$DEST/$f"; else cp -a "$BACKUP/$f" "$DEST/$f"; fi
  done
  cp -a "$BACKUP/nginx.conf" "$NGINX_CONF"
  if nginx -t; then
    if ! systemctl reload nginx; then
      echo "WARNING: Nginx reload after rollback failed; check service status manually." >&2
    fi
  else
    echo "WARNING: Restored Nginx configuration failed validation; reload skipped." >&2
  fi
  echo "Installation failed (exit $original_status). Previous files and Nginx configuration restored. Backup: $BACKUP" >&2
  exit "$original_status"
}
trap rollback ERR
python3 - "$DEST/files.php" "$NGINX_CONF" <<'PY'
from pathlib import Path
import sys,re
p=Path(sys.argv[1]); s=p.read_text()
if 'href="/file_terminal.php"' not in s:
    new,n=re.subn(r'(<a\s+href="/">)\s*ターミナルへ\s*(</a>)',r'<a href="/file_terminal.php">ファイルターミナルへ</a>',s,count=1)
    if n!=1: raise SystemExit('Cannot identify existing terminal link in files.php; no changes applied')
    p.write_text(new)
c=Path(sys.argv[2]); conf=c.read_text()
if not re.search(r'location\s*=\s*/file_terminal\.php\s*\{',conf):
    match=re.search(r'(?m)^(\s*)location\s*=\s*/files\.php\s*\{[^\n]*fastcgi_pass\s+([^;]+);[^\n]*\}',conf)
    if not match: raise SystemExit('Cannot find single-line files.php PHP location in Nginx configuration')
    indent,upstream=match.group(1),match.group(2)
    rule=f'{indent}location = /file_terminal.php {{ include fastcgi_params; fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name; fastcgi_pass {upstream}; }}\n'
    conf=conf[:match.end()]+ '\n'+rule.rstrip('\n')+conf[match.end():]
    c.write_text(conf)
PY
for f in file_terminal.php file_terminal.js file_terminal.css; do install -m 0644 "$HERE/public/$f" "$DEST/$f"; done
php -l "$DEST/file_terminal.php" >/dev/null
nginx -t
systemctl reload nginx
trap - ERR
echo "APFT 1.3 installed. Backup: $BACKUP"
echo 'Open /files.php and click ファイルターミナルへ.'
