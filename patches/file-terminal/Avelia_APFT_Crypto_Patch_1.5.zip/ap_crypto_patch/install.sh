#!/usr/bin/env bash
set -euo pipefail
DEST="${1:-/opt/avelia-web-terminal/public}"
HERE="$(cd "$(dirname "$0")" && pwd)"
[[ $EUID -eq 0 ]] || { echo 'Run with sudo' >&2; exit 1; }
for f in auth.php folder_protection.php files_api.php file_terminal.js file_terminal.php; do
  [[ -f "$DEST/$f" ]] || { echo "Missing $DEST/$f" >&2; exit 1; }
done
command -v php >/dev/null
BACKUP="$(mktemp -d /var/tmp/apft-crypto-backup.XXXXXXXX)"
for f in files_api.php file_terminal.js file_terminal.php file_crypto.php; do
  if [[ -e "$DEST/$f" ]]; then cp -a "$DEST/$f" "$BACKUP/$f"; else touch "$BACKUP/$f.absent"; fi
done
rollback() {
  local code=$?
  trap - ERR
  set +e
  for f in files_api.php file_terminal.js file_terminal.php file_crypto.php; do
    if [[ -f "$BACKUP/$f.absent" ]]; then rm -f "$DEST/$f"; else cp -a "$BACKUP/$f" "$DEST/$f"; fi
  done
  echo "Installation rolled back. Backup: $BACKUP" >&2
  exit "$code"
}
trap rollback ERR
python3 - "$DEST" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); api=p/'files_api.php'; js=p/'file_terminal.js'; page=p/'file_terminal.php'
a=api.read_text(); s=js.read_text(); h=page.read_text()
if "crypto_action($action)" in a or "case 'encrypt'" in s: raise SystemExit('Crypto commands already installed, refusing to patch twice')
needle="    require_post();\n    $path=checked_path((string)($_POST['path']??''));"
assert a.count(needle)==1, 'Unknown files_api.php structure'
a=a.replace(needle,"    require_post();\n    if(in_array($action,['encrypt','decrypt'],true)) {\n        require_once __DIR__.'/file_crypto.php';\n        crypto_action($action);\n    }\n    $path=checked_path((string)($_POST['path']??''));")
anchor="case 'pwd':print('/'+cwd);break;"
assert s.count(anchor)==1, 'Unknown terminal JS structure'
insert="""case 'encrypt':case 'decrypt':{
if(!args[0]||args.length!==1)throw Error('Usage: '+cmd+' <file>');
const password=window.prompt((cmd==='encrypt'?'暗号化':'復号化')+'パスワード (8文字以上)');
if(password===null){print('Cancelled');break;}
if(new TextEncoder().encode(password).length<8)throw Error('Password must be at least 8 bytes');
const j=await api(cmd,{path:target,password});
print((cmd==='encrypt'?'Encrypted: ':'Decrypted: ')+'/'+j.path);break;}
"""
s=s.replace(anchor,insert+anchor)
s=s.replace("unprotect <dir>, clear'", "unprotect <dir>, encrypt <file>, decrypt <file.enc>, clear'")
s=s.replace('File Terminal 1.4', 'File Terminal 1.5')
h=h.replace('v1.4','v1.5').replace('file_terminal.js?v=1.4','file_terminal.js?v=1.5').replace('file_terminal.css?v=1.4','file_terminal.css?v=1.5')
api.write_text(a);js.write_text(s);page.write_text(h)
PY
install -m 0644 "$HERE/file_crypto.php" "$DEST/file_crypto.php"
php -l "$DEST/files_api.php" >/dev/null
php -l "$DEST/file_crypto.php" >/dev/null
php -l "$DEST/file_terminal.php" >/dev/null
trap - ERR
echo "Installed APFT crypto extension. Backup: $BACKUP"
echo 'No Nginx configuration changes are necessary.'
