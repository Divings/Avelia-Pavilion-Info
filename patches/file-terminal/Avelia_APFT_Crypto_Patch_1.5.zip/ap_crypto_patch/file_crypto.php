<?php
declare(strict_types=1);
// Loaded from authenticated files_api.php. This module is not a standalone endpoint.
function crypto_action(string $action): never {
    $relative = (string)($_POST['path'] ?? '');
    $source = checked_path($relative);
    protect_access($relative);
    if (!is_file($source) || !is_readable($source) || $source === ROOT) fail_json('Source file not found',404);
    $password=(string)($_POST['password']??'');
    if (strlen($password)<8 || strlen($password)>1024) fail_json('Password must be between 8 and 1024 bytes');
    $isEncrypt=$action==='encrypt';
    if ($isEncrypt) {
        $destinationRelative=$relative.'.enc';
    } else {
        if (!str_ends_with($relative,'.enc')) fail_json('Expected a .enc file');
        $destinationRelative=substr($relative,0,-4);
        if ($destinationRelative==='') fail_json('Invalid output path');
    }
    $destination=checked_path($destinationRelative);
    protect_access($destinationRelative);
    if ($destination===ROOT || !is_dir(dirname($destination))) fail_json('Invalid output directory');
    if (file_exists($destination) || is_link($destination)) fail_json('Destination already exists',409);
    // Bounded memory processing: compatible with the existing 20 MB file API limit.
    $size=filesize($source);
    if ($size===false || $size>20*1024*1024+52) fail_json('File exceeds 20 MB limit',413);
    $contents=file_get_contents($source);
    if ($contents===false) fail_json('Cannot read input',500);
    $magic="AVENC001";
    if ($isEncrypt) {
        if (strlen($contents)>20*1024*1024) fail_json('File exceeds 20 MB limit',413);
        $salt=random_bytes(16); $iv=random_bytes(12); $tag='';
        $key=hash_pbkdf2('sha256',$password,$salt,600000,32,true);
        $cipher=openssl_encrypt($contents,'aes-256-gcm',$key,OPENSSL_RAW_DATA,$iv,$tag,'',16);
        if ($cipher===false || strlen($tag)!==16) fail_json('Encryption failed',500);
        $result=$magic.$salt.$iv.$tag.$cipher;
    } else {
        if (strlen($contents)<52 || substr($contents,0,8)!==$magic) fail_json('Not a supported encrypted file');
        $salt=substr($contents,8,16); $iv=substr($contents,24,12); $tag=substr($contents,36,16);
        $cipher=substr($contents,52);
        $key=hash_pbkdf2('sha256',$password,$salt,600000,32,true);
        $result=openssl_decrypt($cipher,'aes-256-gcm',$key,OPENSSL_RAW_DATA,$iv,$tag);
        if ($result===false) fail_json('Incorrect password or damaged file',422);
    }
    // Exclusive creation. Never overwrite an existing file.
    $fp=@fopen($destination,'x+b');
    if ($fp===false) fail_json('Cannot create output (may already exist)',409);
    try {
        @chmod($destination,0660);
        $written=0; $length=strlen($result);
        while ($written<$length) {
            $n=fwrite($fp,substr($result,$written,65536));
            if ($n===false || $n===0) throw new RuntimeException('Write failed');
            $written+=$n;
        }
        if (!fflush($fp)) throw new RuntimeException('Flush failed');
    } catch (Throwable $e) {
        fclose($fp); @unlink($destination);
        fail_json('Cannot save encrypted output',500);
    }
    fclose($fp);
    header('Cache-Control: no-store');
    echo json_encode(['ok'=>true,'path'=>$destinationRelative],JSON_UNESCAPED_UNICODE);exit;
}
