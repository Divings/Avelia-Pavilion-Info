Avelia Pavilion File Terminal - encryption/decryption patch (APFT 1.5)

Install on the existing APFT 1.4 deployment:
  sudo bash install.sh
or:
  sudo bash install.sh /custom/web/public

Console commands:
  encrypt relative/path/file.pdf       -> relative/path/file.pdf.enc
  decrypt relative/path/file.pdf.enc   -> relative/path/file.pdf

The original is never deleted. An existing destination is never overwritten.
Each operation prompts for a password separately (not stored in command history).
Format: AVENC001 (8 bytes) + PBKDF2 salt (16) + AES-GCM nonce (12)
      + AES-GCM tag (16) + encrypted file bytes.
Crypto: PBKDF2-HMAC-SHA256 (600,000 iterations) and AES-256-GCM.
Requires PHP OpenSSL extension and enough RAM for a 20 MB file.
Folder protection, session auth and CSRF are enforced through files_api.php.

Security notes:
- Use HTTPS for remote access. Plaintext passwords travel in the POST body.
- Passwords cannot be recovered; keep them in a secure password manager.
- This implementation processes files up to 20 MB entirely in memory.
- Do not expose file_crypto.php as an independent web endpoint.
- Make a VM snapshot / backup before installing. Test in staging first.
- This patch is not compatible with other packages if they have independently
  replaced the targeted API/terminal structure: the installer fails closed.
- Only run on a trusted system. Symlink race hardening and large-file streaming
  are not implemented; do not treat this as a security-audited product.
